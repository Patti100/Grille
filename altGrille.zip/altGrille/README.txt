A Pen created at CodePen.io. You can find this one at http://codepen.io/enzob1990/pen/ByBwZJ.

 just doing a template for a webpage where u could add all kind of things